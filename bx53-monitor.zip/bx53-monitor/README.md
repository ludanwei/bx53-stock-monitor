# BX-53 Amazon Japan monitor

Checks BEYBLADE X BX-53 (ASIN B0HJ75X3PN) with a best-effort five-minute GitHub Actions schedule. Checks require explicit Amazon.co.jp seller, price <= ¥7,480, and availability. Unknown is **never** interpreted as in stock. Amazon may block automated requests, and page changes can cause false negatives. No purchasing, logging in, or payment.

For notifications, configure repository **Settings → Secrets and variables → Actions** with `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`. Without these, only workflow logs are produced. Do not commit tokens. Test via **Actions → BX53 Stock Monitor → Run workflow** and inspect logs. GitHub scheduled jobs can be delayed or skipped.
