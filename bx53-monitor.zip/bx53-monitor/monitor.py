import os, re, json, datetime
from decimal import Decimal
import requests
from bs4 import BeautifulSoup

ASIN = 'B0HJ75X3PN'
URL = f'https://www.amazon.co.jp/dp/{ASIN}'
LIMIT = Decimal('7480')
HEADERS = {'User-Agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36', 'Accept-Language':'ja-JP,ja;q=0.9'}

def check():
    try:
        resp = requests.get(URL, headers=HEADERS, timeout=20)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, 'html.parser')
        title = soup.select_one('#productTitle')
        if not title or not any(x in title.get_text(' ',strip=True) for x in ('BX-53','オールインワンセット')):
            return {'status':'unknown','reason':'Product identity unconfirmed or blocked'}
        # Seller must be explicitly labeled. Amazon fulfillment alone is not sufficient.
        seller = soup.select_one('#sellerProfileTriggerId')
        if not seller or seller.get_text(' ',strip=True) != 'Amazon.co.jp':
            return {'status':'unknown','reason':'Amazon.co.jp direct seller not explicitly verified'}
        price_el = soup.select_one('#corePrice_feature_div .a-offscreen, #corePriceDisplay_desktop_feature_div .a-offscreen')
        if not price_el:
            return {'status':'unknown','reason':'Price not verified'}
        digits = re.sub(r'[^0-9]', '', price_el.get_text(' ',strip=True))
        if not digits:
            return {'status':'unknown','reason':'Price invalid'}
        price = Decimal(digits)
        if price > LIMIT:
            return {'status':'unavailable','reason':'Above maximum price','price':str(price)}
        avail = soup.select_one('#availability')
        if not avail or '在庫あり' not in avail.get_text(' ',strip=True):
            return {'status':'unknown','reason':'One unit available not verified'}
        return {'status':'candidate','price':str(price),'seller':'Amazon.co.jp'}
    except requests.RequestException as exc:
        return {'status':'unknown','reason':f'Network failure: {type(exc).__name__}'}

def notify(msg):
    token = os.environ.get('TELEGRAM_BOT_TOKEN')
    chat_id = os.environ.get('TELEGRAM_CHAT_ID')
    if not (token and chat_id):
        print('Notification not configured; no alert sent')
        return
    response = requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id':chat_id,'text':msg}, timeout=15)
    response.raise_for_status()

if __name__ == '__main__':
    result = check()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(json.dumps({'timestamp_utc':now, 'url':URL, **result}, ensure_ascii=False))
    if result['status'] == 'candidate':
        notify(f'BX-53 可能補貨，請人工核對並下單。\n¥{result["price"]} / Amazon.co.jp\n{URL}\nUTC {now}')
